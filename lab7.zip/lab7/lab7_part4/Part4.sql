DELIMITER //
CREATE TRIGGER Checkadministrative 
BEFORE INSERT ON Participates
FOR EACH ROW
	BEGIN 
		IF EXISTS (
			SELECT 1
			FROM Administrative A
			WHERE A.pid = NEW.pid
		)THEN
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'Administrative cannot participate';
END IF;
END//
DELIMITER ;

DELIMITER //
CREATE TRIGGER Checkadministrativeupdate 
BEFORE UPDATE ON Participates
FOR EACH ROW
	BEGIN 
		IF EXISTS (
			SELECT 1
			FROM Administrative A
			WHERE A.pid = NEW.pid
		)THEN
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'Administrative cannot participate';
END IF;
END//
DELIMITER ;

DELIMITER //
CREATE TRIGGER INSERTPICOPI
BEFORE INSERT ON Participates
FOR EACH ROW
	BEGIN 
		IF NEW.role IN ( 'PI','Co-PI')
        AND NOT EXISTS(
       SELECT 1
       FROM Academic A
       WHERE A.pid = NEW.pid
        )
	THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'PI and Co-PI must be academic';
END IF;
END//
DELIMITER ;

DELIMITER //
CREATE TRIGGER UPDATEPICOPIUpdate
BEFORE UPDATE ON Participates
FOR EACH ROW
BEGIN
    IF NEW.role IN ('PI', 'Co-PI')
       AND NOT EXISTS (
           SELECT 1
           FROM Academic A
           WHERE A.pid = NEW.pid
       )THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'PI and Co-PI must be academic';
    END IF;
END//
DELIMITER ;

DELIMITER //
CREATE TRIGGER CheckMorePIINSERTED
BEFORE INSERT ON Participates
FOR EACH ROW
	BEGIN
	IF NEW.role IN ('PI', 'Co-PI')
    AND EXISTS (
            SELECT 1
			FROM Participates P
			WHERE P.role = NEW.role AND P.pid <> NEW.pid AND P.projectCode = NEW.projectCode
		)
        THEN
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'IT MUST BE ONE Co-PI IN A RESEARCH PROJECT';
END IF;
END//
DELIMITER ;

DELIMITER //
CREATE TRIGGER CheckMorePIUPDATED
BEFORE UPDATE ON Participates
FOR EACH ROW
	BEGIN 
	IF NEW.role IN ('PI', 'Co-PI')
    AND EXISTS (
            SELECT 1
			FROM Participates P
			WHERE P.role = NEW.role AND P.projectCode = NEW.projectCode
            AND NOT(
            P.pid = NEW.pid
			)
		)
        THEN
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'IT MUST BE ONE PI IN A RESEARCH PROJECT';
END IF;
END//
DELIMITER ;

DELIMITER //
CREATE TRIGGER AddEquiUnitToReservationInsert
BEFORE INSERT ON Reserves
FOR EACH ROW 
	BEGIN
    
    IF EXISTS(
		SELECT 1
        FROM Reservation N
        JOIN Reserves R ON R.serialNo = NEW.serialNo
        JOIN Reservation Rv ON Rv.resId = R.resId
        WHERE N.resId = NEW.resId
          AND N.status = 'approved'
          AND Rv.status = 'approved'
          AND N.plannedStart < Rv.plannedEnd
          AND N.plannedEnd > Rv.plannedStart
          AND Rv.resId <> N.resId
          )
    THEN
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'THERE IS AN EXISTING APPROVED RESERVATION AT THE SAME TIME';
END IF;
END//
DELIMITER;

DELIMITER //
CREATE TRIGGER AddEquiUnitToReservationUpdate
BEFORE UPDATE ON Reservation
FOR EACH ROW 
BEGIN
    IF NEW.status = 'Approved'
       AND EXISTS (
           SELECT 1
           FROM Reservation N
           JOIN Reserves R
               ON R.resId = N.resId
           JOIN Reserves R2
               ON R2.serialNo = R.serialNo
           JOIN Reservation Rv
               ON Rv.resId = R2.resId
           WHERE N.resId = OLD.resId
             AND Rv.status = 'Approved'
             AND NEW.plannedStart < Rv.plannedEnd
             AND NEW.plannedEnd > Rv.plannedStart
             AND Rv.resId <> N.resId
			)
    THEN
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'THERE IS AN EXISTING APPROVED RESERVATION AT THE SAME TIME';
END IF;
END//
DELIMITER;


DELIMITER //

CREATE TRIGGER consumption_validation
BEFORE INSERT ON Consumes
FOR EACH ROW
BEGIN
    IF NEW.quantityUsed <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Quantity must be positive';
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM Stocks S
        WHERE S.labId = NEW.labId
          AND S.consId = NEW.consId
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Stock does not exist';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM Stocks S
        WHERE S.labId = NEW.labId
          AND S.consId = NEW.consId
          AND NEW.quantityUsed > S.quantityOnHand
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Insufficient stock';
    END IF;
END//

DELIMITER ;


DELIMITER //

CREATE TRIGGER update_stock
AFTER INSERT ON Consumes
FOR EACH ROW
BEGIN
    UPDATE Stocks
    SET quantityOnHand = quantityOnHand - NEW.quantityUsed
    WHERE labId = NEW.labId
      AND consId = NEW.consId;
END//

DELIMITER ;


DELIMITER //
CREATE TRIGGER IsEligable
BEFORE INSERT ON Reserves
FOR EACH ROW
BEGIN
    DECLARE target_date DATE;

    SELECT R.plannedStart
    INTO target_date
    FROM Reservation AS R
    WHERE R.resId = NEW.resId;

    IF EXISTS (
        SELECT REQ.certCode
        FROM Equipment_Unit AS EU
        JOIN Equipment_Model AS EM
            ON EU.modelId = EM.modelId
        JOIN Requires AS REQ
            ON EM.modelId = REQ.modelId
        WHERE EU.serialNo = NEW.serialNo
          AND NOT EXISTS (
              SELECT H.certCode
              FROM Reservation AS R
              JOIN Person AS P
                  ON R.madeByPid = P.pid
              JOIN Holds AS H
                  ON P.pid = H.pid
              WHERE R.resId = NEW.resId
                AND H.certCode = REQ.certCode
                AND H.expirationDate >= target_date
          )
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Not a valid reservation';
    END IF;
END //

DELIMITER ;

DELIMITER //
-- 6
-- a
create trigger disjoint_student_employee_on_insert_1 BEFORE INSERT ON Student
FOR EACH ROW
BEGIN
	IF exists(
		select 1 from Employee E where E.pid = NEW.pid 
	)then SIGNAL SQLSTATE "45000"
		SET MESSAGE_TEXT = "One of the students you are trying to insert is already an employee";
		
	END IF;
END //

create trigger disjoint_student_employee_on_insert_2 BEFORE INSERT ON Employee
FOR EACH ROW
BEGIN 
	IF exists(
		select 1 from Student S where S.pid = NEW.pid
	)then SIGNAL SQLSTATE "45000"
		SET MESSAGE_TEXT = "One of the employees you are trying to insert is already a student";
		
	END IF;
END //

create trigger disjoint_student_employee_on_update_1 BEFORE UPDATE ON Student
FOR EACH ROW
BEGIN
	IF exists(
		select 1 from Employee E where E.pid = NEW.pid 
	)then SIGNAL SQLSTATE "45000"
		SET MESSAGE_TEXT = "The pid you defined for one of the updated students already exists for an employee";
		
	END IF;
END //

create trigger disjoint_student_employee_on_update_2 BEFORE UPDATE ON Employee
FOR EACH ROW
BEGIN
	IF exists(
		select 1 from Student S where S.pid = NEW.pid 
	)then SIGNAL SQLSTATE "45000"
		SET MESSAGE_TEXT = "The pid you defined for one of the updated employees already exists for a student";
		
	END IF;
END //


-- b

create trigger faculties_report_to_dean BEFORE INSERT ON Faculty
FOR EACH ROW
BEGIN
	IF ((select supervisorPid from Employee where pid=NEW.pid) is NULL) OR "dean" <> (select E.position from Employee E where E.pid = (select supervisorPid from Employee where pid=NEW.pid))
	then SIGNAL SQLSTATE "45000"
		SET MESSAGE_TEXT = "One of the inserted faculties does not report to the dean";
	END IF;
END //

create trigger administratives_report_to_dean BEFORE INSERT ON Administrative
FOR EACH ROW
BEGIN
	IF ((select supervisorPid from Employee where pid=NEW.pid) is NULL) OR "dean" <> (select E.position from Employee E where E.pid = (select supervisorPid from Employee where pid=NEW.pid))
	then SIGNAL SQLSTATE "45000"
		SET MESSAGE_TEXT = "One of the inserted administratives does not report to the dean";
	END IF;
END //

create trigger employee_before_update_reported_to_dean BEFORE UPDATE ON Employee
FOR EACH ROW
BEGIN
	IF exists(select 1 from Faculty F where F.pid = NEW.pid UNION select 1 from Administrative A where A.pid = NEW.pid) and ((NEW.supervisorPid is NULL) or "dean" <> (select E.position from Employee E where E.pid = NEW.supervisorPid)) 
	then SIGNAL SQLSTATE "45000"
		SET MESSAGE_TEXT = "The updated employee does not report to the correct supervisor";
	END IF;
END //


-- c

create trigger deans_report_to_nobody_insert BEFORE INSERT ON Employee
FOR EACH ROW
BEGIN
	IF (NEW.position = "dean") and (NEW.supervisorPid is not NULL)
	then SIGNAL SQLSTATE "45000"
		SET MESSAGE_TEXT = "You tried to insert a dean with a non null supervisor";
	END IF;
END //

create trigger deans_report_to_nobody_update BEFORE UPDATE ON Employee 
FOR EACH ROW
BEGIN
	IF (NEW.position = "dean") and (NEW.supervisorPid is not NULL)
	then SIGNAL SQLSTATE "45000"
		SET MESSAGE_TEXT = "You tried to update an employee to a dean with a non null supervisor";
	END IF;
END //

DELIMITER ;



-- 1
INSERT INTO Participates (pid, projectCode, role)
VALUES (12, 'RP-003', 'Collaborator');
DELETE FROM Participates WHERE pid = 12 AND projectCode = 'RP-003';

INSERT INTO Participates (pid, projectCode, role)
VALUES (8, 'RP-003', 'Collaborator');


-- 2
UPDATE Participates SET pid = 12
WHERE pid = 11 AND projectCode = 'RP-003';
UPDATE Participates SET pid = 11
WHERE pid = 12 AND projectCode = 'RP-003';

UPDATE Participates SET pid = 8
WHERE pid = 11 AND projectCode = 'RP-003';


-- 3
INSERT INTO Participates (pid, projectCode, role)
VALUES (5, 'RP-003', 'Co-PI');
DELETE FROM Participates WHERE pid = 5 AND projectCode = 'RP-003';

INSERT INTO Participates (pid, projectCode, role)
VALUES (10, 'RP-003', 'Co-PI');


-- 4
UPDATE Participates SET role = 'Co-PI'
WHERE pid = 5 AND projectCode = 'RP-004';
UPDATE Participates SET role = 'Collaborator'
WHERE pid = 5 AND projectCode = 'RP-004';

UPDATE Participates SET role = 'Co-PI'
WHERE pid = 7 AND projectCode = 'RP-002';


-- 5
INSERT INTO Participates (pid, projectCode, role)
VALUES (5, 'RP-002', 'Co-PI');
DELETE FROM Participates WHERE pid = 5 AND projectCode = 'RP-002';

INSERT INTO Participates (pid, projectCode, role)
VALUES (4, 'RP-002', 'PI');


-- 6
UPDATE Participates SET role = 'Co-PI'
WHERE pid = 5 AND projectCode = 'RP-004';
UPDATE Participates SET role = 'Collaborator'
WHERE pid = 5 AND projectCode = 'RP-004';

UPDATE Participates SET role = 'PI'
WHERE pid = 5 AND projectCode = 'RP-004';


-- 7
INSERT INTO Reserves (resId, serialNo)
VALUES (4, 'SN-OM100-001');
DELETE FROM Reserves
WHERE resId = 4 AND serialNo = 'SN-OM100-001';

INSERT INTO Reservation
(resId, submissionTS, plannedStart, plannedEnd, purpose, status,
 madeByPid, projectCode, approverPid)
SELECT 970, NOW(), plannedStart, plannedEnd,
       'Conflicting unit insert', 'Approved', 2, 'RP-001', 1
FROM Reservation WHERE resId = 1;
INSERT INTO Reserves (resId, serialNo)
VALUES (970, 'SN-OM200-001');
DELETE FROM Reservation WHERE resId = 970;


-- 8
UPDATE Reservation SET status = 'Approved', approverPid = 1
WHERE resId = 4;
UPDATE Reservation SET status = 'Rejected', approverPid = NULL
WHERE resId = 4;

INSERT INTO Reservation
(resId, submissionTS, plannedStart, plannedEnd, purpose, status,
 madeByPid, projectCode)
SELECT 971, NOW(), plannedStart, plannedEnd,
       'Conflicting approval', 'Pending', 2, 'RP-001'
FROM Reservation WHERE resId = 1;
INSERT INTO Reserves (resId, serialNo)
VALUES (971, 'SN-OM200-001');
UPDATE Reservation SET status = 'Approved', approverPid = 1
WHERE resId = 971;
DELETE FROM Reserves WHERE resId = 971 AND serialNo = 'SN-OM200-001';
DELETE FROM Reservation WHERE resId = 971;

-- 9
INSERT INTO Consumes (resId, labId, consId, quantityUsed)
VALUES (2, 1, 1, 5);
SELECT quantityOnHand
FROM Stocks
WHERE labId = 1 AND consId = 1;

INSERT INTO Consumes (resId, labId, consId, quantityUsed)
VALUES (3, 1, 1, -5);

INSERT INTO Consumes (resId, labId, consId, quantityUsed)
VALUES (3, 1, 1, 1000);

INSERT INTO Consumes (resId, labId, consId, quantityUsed)
VALUES (3, 1, 4, 2);
-- 10
INSERT INTO Reserves (resId, serialNo)
VALUES (4, 'SN-OM100-003');
DELETE FROM Reserves
WHERE resId = 4 AND serialNo = 'SN-OM100-003';

INSERT INTO Reserves (resId, serialNo)
VALUES (8, 'SN-OM200-001');

UPDATE Holds SET expirationDate = '2026-01-01'
WHERE pid = 4 AND certCode = 'CERT-OPT';
INSERT INTO Reserves (resId, serialNo)
VALUES (4, 'SN-OM100-003');
UPDATE Holds SET expirationDate = '2030-09-30'
WHERE pid = 4 AND certCode = 'CERT-OPT';

-- 11
SELECT E.pid, E.position
FROM Employee E
WHERE E.position <> 'dean'
  AND NOT EXISTS (
      SELECT 1 FROM Faculty F WHERE F.pid = E.pid
  )
  AND NOT EXISTS (
      SELECT 1 FROM Administrative A WHERE A.pid = E.pid
  );
  
  UPDATE Employee
SET position = 'dean',
    supervisorPid = NULL
WHERE pid = 10;

UPDATE Employee
SET supervisorPid = 5
WHERE pid = 10;