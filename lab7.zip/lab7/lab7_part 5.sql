-- ============================================================
-- PART 5: DATABASE PROGRAMMING
-- ============================================================

-- 1. Stored function and demonstration query

DELIMITER //

CREATE FUNCTION availableUnits(mId INT)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE model_id_count INT;

    SELECT COUNT(*)
    INTO model_id_count
    FROM Equipment_Unit
    WHERE modelId = mId
      AND status = 'InService';

    RETURN model_id_count;
END //

DELIMITER ;

SELECT commercialName, availableUnits(modelId) AS availableUnitCount
FROM Equipment_Model;


-- 2. Stored procedure and demonstrations

DELIMITER //

CREATE PROCEDURE RestockLab(
    IN p_labId INT,
    IN p_consId INT,
    IN p_qty DECIMAL(12, 2),
    OUT newQuantity DECIMAL(12, 2)
)
BEGIN
    IF p_qty <= 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Quantity must be positive';
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM Stocks AS S
        WHERE S.labId = p_labId
          AND S.consId = p_consId
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'No stock exists for this lab and consumable';
    END IF;

    SELECT quantityOnHand + p_qty
    INTO newQuantity
    FROM Stocks
    WHERE labId = p_labId
      AND consId = p_consId;

    UPDATE Stocks
    SET quantityOnHand = newQuantity,
        lastRestockDate = CURRENT_DATE
    WHERE labId = p_labId
      AND consId = p_consId;
END //

DELIMITER ;

-- Successful call and returned quantity

CALL RestockLab(1, 1, 5, @newQuantity);
SELECT @newQuantity AS newQuantity;

-- Rejection demonstrations

CALL RestockLab(1, 1, 0, @newQuantity);
CALL RestockLab(2, 2, 5, @newQuantity);


-- 3. Parameterized query from Python

-- The program connects to RLMS, searches for InService equipment in the
-- selected laboratory, and prints each unit's serial number and model name.

-- import mysql.connector
--
-- connection = mysql.connector.connect(
--     host="localhost",
--     user="root",
--     password="YOUR_MYSQL_PASSWORD",
--     database="RLMS"
-- )
--
-- cursor = connection.cursor()
-- lab_name = "Physics Laboratory"
--
-- query = """
--     SELECT EU.serialNo, EM.commercialName
--     FROM Equipment_Unit AS EU
--     JOIN Equipment_Model AS EM ON EU.modelId = EM.modelId
--     JOIN Laboratory AS L ON EU.labId = L.labId
--     WHERE EU.status = 'InService'
--       AND L.name = %s
-- """
--
-- cursor.execute(query, (lab_name,))
--
-- for serial_no, model_name in cursor:
--     print(serial_no, model_name)


-- 4. LaboratoryStockSummary view and Python query

-- The view labels each stock occurrence as LOW when its quantity is at or
-- below its reorder threshold, and OK when it is above that threshold.

CREATE OR REPLACE VIEW LaboratoryStockSummary AS
SELECT
    L.labId,
    L.name AS labName,
    C.consId,
    C.name AS consumableName,
    C.unitOfMeasure,
    S.quantityOnHand,
    C.reorderThreshold,
    S.technicalPid,
    S.monitoringSince,
    'LOW' AS stockLevel
FROM Stocks AS S
JOIN Laboratory AS L ON L.labId = S.labId
JOIN Consumable AS C ON C.consId = S.consId
WHERE S.quantityOnHand <= C.reorderThreshold

UNION ALL

SELECT
    L.labId,
    L.name AS labName,
    C.consId,
    C.name AS consumableName,
    C.unitOfMeasure,
    S.quantityOnHand,
    C.reorderThreshold,
    S.technicalPid,
    S.monitoringSince,
    'OK' AS stockLevel
FROM Stocks AS S
JOIN Laboratory AS L ON L.labId = S.labId
JOIN Consumable AS C ON C.consId = S.consId
WHERE S.quantityOnHand > C.reorderThreshold;

-- The Python query selects and prints only the LOW stock rows.

-- cursor.execute("""
--     SELECT labName, consumableName, quantityOnHand, reorderThreshold
--     FROM LaboratoryStockSummary
--     WHERE stockLevel = %s
-- """, ("LOW",))
--
-- for lab_name, consumable_name, quantity, threshold in cursor:
--     print(lab_name, consumable_name, quantity, threshold)


-- 5. Calling RestockLab from Python

-- The program calls the stored procedure for a stock occurrence and prints
-- the returned quantity.

-- lab_id = 1
-- cons_id = 1
-- qty = 5
--
-- result = cursor.callproc("RestockLab", [lab_id, cons_id, qty, 0])
-- connection.commit()
-- print("New quantity:", result[3])


-- 6. Handling a certification-trigger error in Python

-- The attempted insert is rejected by the certification trigger. The program
-- catches the database error and prints the trigger's message.

-- try:
--     cursor.execute(
--         "INSERT INTO Reserves (resId, serialNo) VALUES (%s, %s)",
--         (1, "U2")
--     )
--     connection.commit()
--     print("Reservation accepted.")
-- except mysql.connector.Error as err:
--     connection.rollback()
--     print("Reservation rejected:", err.msg)

-- Execution output:
-- Reservation rejected: Not a valid reservation


-- 7. Schema change

-- (a) After Consumable.name is renamed to designation, the unmodified program
-- produces the following error because LaboratoryStockSummary still refers
-- to the old column name.

ALTER TABLE Consumable RENAME COLUMN name TO designation;

-- Execution error:
-- Exception has occurred: DatabaseError
--
-- 1356 (HY000): View 'rlms.laboratorystocksummary' references invalid table(s)
-- or column(s) or function(s) or definer/invoker of view lack rights to use them
--
-- _mysql_connector.MySQLInterfaceError: View 'rlms.laboratorystocksummary'
-- references invalid table(s) or column(s) or function(s) or definer/invoker
-- of view lack rights to use them

-- (b) The view is updated to use Consumable.designation while retaining the
-- same output column name, consumableName.

CREATE OR REPLACE VIEW LaboratoryStockSummary AS
SELECT
    L.labId,
    L.name AS labName,
    C.consId,
    C.designation AS consumableName,
    C.unitOfMeasure,
    S.quantityOnHand,
    C.reorderThreshold,
    S.technicalPid,
    S.monitoringSince,
    'LOW' AS stockLevel
FROM Stocks AS S
JOIN Laboratory AS L ON L.labId = S.labId
JOIN Consumable AS C ON C.consId = S.consId
WHERE S.quantityOnHand <= C.reorderThreshold

UNION ALL

SELECT
    L.labId,
    L.name AS labName,
    C.consId,
    C.designation AS consumableName,
    C.unitOfMeasure,
    S.quantityOnHand,
    C.reorderThreshold,
    S.technicalPid,
    S.monitoringSince,
    'OK' AS stockLevel
FROM Stocks AS S
JOIN Laboratory AS L ON L.labId = S.labId
JOIN Consumable AS C ON C.consId = S.consId
WHERE S.quantityOnHand > C.reorderThreshold;

-- Execution output after updating the view:
-- Physics Laboratory Nitrile Gloves 8.00 10.00
-- Data Systems Lab Nitrile Gloves 4.00 10.00

-- (c) The experiment illustrates logical data independence. The Consumable
-- table changed when name was renamed to designation, but the program kept
-- working because the view was updated to use the new column name while
-- preserving the same output columns.
--
-- The Task 3 query would not survive renaming Laboratory.name because it
-- refers directly to that column. It would need to be updated.

-- (d) The Consumable column is renamed back, and the original view is restored.

ALTER TABLE Consumable RENAME COLUMN designation TO name;

CREATE OR REPLACE VIEW LaboratoryStockSummary AS
SELECT
    L.labId,
    L.name AS labName,
    C.consId,
    C.name AS consumableName,
    C.unitOfMeasure,
    S.quantityOnHand,
    C.reorderThreshold,
    S.technicalPid,
    S.monitoringSince,
    'LOW' AS stockLevel
FROM Stocks AS S
JOIN Laboratory AS L ON L.labId = S.labId
JOIN Consumable AS C ON C.consId = S.consId
WHERE S.quantityOnHand <= C.reorderThreshold

UNION ALL

SELECT
    L.labId,
    L.name AS labName,
    C.consId,
    C.name AS consumableName,
    C.unitOfMeasure,
    S.quantityOnHand,
    C.reorderThreshold,
    S.technicalPid,
    S.monitoringSince,
    'OK' AS stockLevel
FROM Stocks AS S
JOIN Laboratory AS L ON L.labId = S.labId
JOIN Consumable AS C ON C.consId = S.consId
WHERE S.quantityOnHand > C.reorderThreshold;