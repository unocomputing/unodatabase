--- PART2 LAB7
CREATE OR REPLACE VIEW UpcomingApprovedReservationsByLab AS
SELECT L.labId , L.name, DATE(R.plannedStart) AS reservationDate,count(DISTINCT R.resId) AS distinctApprovedReservation
FROM Reservation R
JOIN Reserves Rs ON R.resId = Rs.resId
JOIN EquipmentUnit E ON Rs.serialNo = E.serialNo
JOIN Laboratory L ON E.labId = L.labId
WHERE R.status = 'Approved'
  AND R.plannedStart >= NOW()
  AND R.plannedStart < NOW() + INTERVAL 14 DAY
GROUP BY
    L.labId,
    DATE(R.plannedStart);
    
-- Shows the number of distinct approved reservations for each laboratory and date within the next 14 days
-- Helps laboratory managers equipment demand and organize laboratory demandings and prepare resources for upcoming reservations.
    
CREATE OR REPLACE VIEW EquipmentInventoryByLab AS
SELECT L.labId, L.name, M.modelId, M.commercialName, M.category, 
COUNT( DISTINCT E.serialNo) AS PhysicalEquipmentUnits,
SUM(CASE WHEN E.status = 'InService' THEN 1 ELSE 0 END) AS UnitsInService ,SUM(CASE WHEN E.status = 'UnderMaintenance' THEN 1 ELSE 0 END) AS UnitsUnderMaintenance
FROM EquipmentUnit E
JOIN EquipmentModel M ON E.modelId = M.modelId
JOIN Laboratory L ON E.labId = L.labId
GROUP BY L.labId,M.modelId;

-- It shows resources of physical euipement units and thoses in service and undermaintenance numbers per laboratory and equipementModel
-- helps the laboratory to manages and indentify maintenants and plan equipement usage

CREATE OR REPLACE VIEW PersonReservationSummary AS 
SELECT P.pid, P.firstName,P.lastName,SUM(CASE WHEN R.status = 'Approved'
        THEN 1 ELSE 0 END) AS approvedReservation,COUNT(R.resId) AS reservation,
    SUM(CASE WHEN R.status = 'Pending'
        THEN 1 ELSE 0 END) AS pendingReservation,
    SUM(CASE WHEN R.status = 'Cancelled'
        THEN 1 ELSE 0 END) AS cancelledReservation
FROM Person P
LEFT JOIN Reservation R ON R.madeByPid=P.pid
GROUP BY P.pid;

-- Summarizes reservations made by each person including the numbers of approved and pending and cancelled reservations.
-- Helps administrators trakc user reservation and status the requests

CREATE OR REPLACE VIEW ProjectReservationSummary AS 
SELECT Pr.code, Pr.title, Pr.status, COUNT(R.resId) AS reservation,SUM(CASE WHEN R.status = 'Approved'
    THEN 1 ELSE 0 END) AS approvedReservation,MIN(CASE WHEN R.plannedStart > CURRENT_TIMESTAMP THEN R.plannedStart ELSE NULL END) AS nextReservation
FROM ResearchProject Pr
LEFT JOIN Reservation R ON R.projectCode=Pr.Code
GROUP BY Pr.Code;

-- Provides reservation statistics for each research project including its status and total number of reservations and next scheduled reservation.
-- it helps project workrs know the upcoming reaserch activities and equipement usage
CREATE OR REPLACE VIEW LaboratoryStockSummary AS
SELECT
    L.labId,
    L.name AS labName,
    C.consId,
    C.name AS consumableName,
    C.unitOfMeasure,
    S.quantityOnHand,
    C.reorderThreshold,
    S.technicalPid,
    S.monitoringSince,
    'LOW' AS stockLevel
FROM Stocks AS S
JOIN Laboratory AS L ON L.labId = S.labId
JOIN Consumable AS C ON C.consId = S.consId
WHERE S.quantityOnHand <= C.reorderThreshold

UNION ALL

SELECT
    L.labId,
    L.name AS labName,
    C.consId,
    C.name AS consumableName,
    C.unitOfMeasure,
    S.quantityOnHand,
    C.reorderThreshold,
    S.technicalPid,
    S.monitoringSince,
    'OK' AS stockLevel
FROM Stocks AS S
JOIN Laboratory AS L ON L.labId = S.labId
JOIN Consumable AS C ON C.consId = S.consId
WHERE S.quantityOnHand > C.reorderThreshold;


SELECT labId, name, reservationDate, distinctApprovedReservation
FROM UpcomingApprovedReservationsByLab
WHERE distinctApprovedReservation > 0
ORDER BY reservationDate;

SELECT labId, commercialName, PhysicalEquipmentUnits, UnitsUnderMaintenance
FROM EquipmentInventoryByLab
WHERE UnitsUnderMaintenance > 0;

SELECT pid, firstName, lastName, approvedReservation
FROM PersonReservationSummary
WHERE approvedReservation > 0
ORDER BY approvedReservation DESC;

SELECT code, title, approvedReservation, nextReservation
FROM ProjectReservationSummary
WHERE approvedReservation > 0
ORDER BY approvedReservation DESC;

SELECT labId, consumableName, quantityOnHand, reorderThreshold
FROM LaboratoryStockSummary
WHERE stockLevel = 'LOW';