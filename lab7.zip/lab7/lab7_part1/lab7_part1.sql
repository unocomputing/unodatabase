USE lab7;
-- Query 1
SELECT
    e.pid AS employeePid,
    CONCAT(pe.firstName, ' ', pe.lastName) AS employeeName,
    e.supervisorPid,
    CONCAT(ps.firstName, ' ', ps.lastName) AS supervisorName
FROM Employee e
JOIN Person pe
    ON e.pid = pe.pid
LEFT JOIN Employee s
    ON e.supervisorPid = s.pid
LEFT JOIN Person ps
    ON s.pid = ps.pid;

-- Query 2
SELECT
    r.resId,
    r.purpose,
    r.status,
    r.approverPid,
    CONCAT(pa.firstName, ' ', pa.lastName) AS approverName
FROM Reservation r
LEFT JOIN Person pa
    ON r.approverPid = pa.pid;

-- Query 3
SELECT
    u1.serialNo AS unit1SerialNo,
    u2.serialNo AS unit2SerialNo,
    u1.modelId,
    u1.labId AS lab1Id,
    u2.labId AS lab2Id
FROM EquipmentUnit u1
JOIN EquipmentUnit u2
    ON u1.modelId = u2.modelId
   AND u1.labId <> u2.labId
   AND u1.serialNo < u2.serialNo;

-- Query 4
SELECT
    m.modelId,
    m.commercialName,
    COUNT(u.serialNo) AS unitCount
FROM EquipmentModel m
LEFT JOIN EquipmentUnit u
    ON m.modelId = u.modelId
GROUP BY m.modelId, m.commercialName;

-- Query 5
SELECT
    u.labId,
    u.serialNo,
    u.purchaseCost
FROM EquipmentUnit u
WHERE u.purchaseCost = (
    SELECT MAX(u2.purchaseCost)
    FROM EquipmentUnit u2
    WHERE u2.labId = u.labId
);

-- Query 6
SELECT
    s.labId,
    SUM(s.quantityOnHand) AS totalStockQuantity
FROM Stocks s
GROUP BY s.labId
HAVING SUM(s.quantityOnHand) > (
    SELECT AVG(labTotals.totalQty)
    FROM (
        SELECT SUM(s2.quantityOnHand) AS totalQty
        FROM Stocks s2
        GROUP BY s2.labId
    ) AS labTotals
);

-- Query 7: Consumables stocked in EVERY laboratory (relational division)
SELECT
    c.consId,
    c.name
FROM Consumable c
WHERE NOT EXISTS (
    SELECT 1
    FROM Laboratory l
    WHERE NOT EXISTS (
        SELECT 1
        FROM Stocks s
        WHERE s.consId = c.consId
          AND s.labId = l.labId
    )
);
