USE lab7;
--  1
ALTER TABLE student
ADD CONSTRAINT check_student_program
CHECK(program IN ('BSc', 'BEng', 'MSc', 'PhD'));
INSERT INTO student VALUES (10, 'MBA');

ALTER TABLE employee
ADD CONSTRAINT check_employee_position
CHECK(position IN ('dean', 'faculty', 'postdoc', 'secretary', 'technician', 'lab manager'));
INSERT INTO employee VALUES (8, '0608', 'C-003', 'janitor',1);

ALTER TABLE researchproject
ADD CONSTRAINT check_rp_status
CHECK(status IN ('Proposed', 'Active', 'Completed', 'Cancelled'));
INSERT INTO researchproject VALUES ('P4', 'Secret Project', '2025-02-01','2029-06-30', 'Incomplete');

ALTER TABLE participates
ADD CONSTRAINT check_p_role
CHECK(role IN ('PI', 'Co-PI', 'Collaborator'));
INSERT INTO participates VALUES (2, 'P3', 'Student');

ALTER TABLE equipmentunit
ADD CONSTRAINT check_eu_status
CHECK(status IN ('InService', 'Under Maintenance', 'OutOfService', 'Retired'));
INSERT INTO equipmentunit VALUES ('U8','2028-03-01',16000.00, 'Not in service', FALSE, 1,1);

ALTER TABLE reservation
ADD CONSTRAINT check_r_status
CHECK(status IN ('Pending', 'Approved', 'Rejected', 'Completed', 'Cancelled'));
INSERT INTO reservation VALUES (7,'2027-08-01 09:00:00', '2027-08-10 08:00:00', '2027-08-12 18:00:00', 'Prototype print', 'Test', 6, 'P1', NULL);

ALTER TABLE maintenance
ADD CONSTRAINT check_maintenance_type
CHECK(type IN ('Preventive', 'Corrective'));
INSERT INTO maintenance VALUES ('U1','2027-04-12 09:00:00','2027-04-12 12:00:00', 'Test', 'Lens cleaning', 150.00, 'Resolved', 7);

ALTER TABLE maintenance
ADD CONSTRAINT check_maintenance_outcome
CHECK(outcome IN ('Resolved', 'FollowUpRequired', 'Unresolved'));
INSERT INTO maintenance VALUES ('U1','2027-04-12 09:00:00','2027-04-12 12:00:00', 'Corrective', 'Lens cleaning', 150.00, 'Test', 7);

ALTER TABLE calibrationrecord
ADD CONSTRAINT check_cr_result
CHECK(result IN ('Pass', 'Fail', 'Adjusted'));
INSERT INTO calibrationrecord VALUES ('U5','2027-06-15', 'axis alignment', 'Test', '2027-12-15', NULL);

--  2
ALTER TABLE budget
ADD CONSTRAINT check_budget_validity
CHECK((amountGranted>=0)AND(amountDisbursed>=0));
INSERT INTO budget VALUES('B3',-1.00,-2.00,'2027-06-01','2029-05-31',4);

ALTER TABLE equipmentunit
ADD CONSTRAINT check_pc_validity
CHECK(purchaseCost>=0);
INSERT INTO equipmentunit VALUES ('U8','2026-03-01',-1.00, 'InService', FALSE, 1,1);

ALTER TABLE maintenance
ADD CONSTRAINT check_cost_validity
CHECK(cost>=0);
INSERT INTO maintenance VALUES ('U1','2027-04-12 09:00:00','2027-04-12 12:00:00', 'Preventive', 'Lens cleaning', -1.00, 'Resolved', 7);

ALTER TABLE supplies
ADD CONSTRAINT check_up_validity
CHECK(unitPrice>=0);
INSERT INTO supplies VALUES (1,3,3,-1.00);

ALTER TABLE consumable
ADD CONSTRAINT check_rth_validity
CHECK(reorderThreshold >=0);
INSERT INTO consumable VALUES (4, 'Reagent X', 'bottle', 'low', -1.00);

ALTER TABLE stocks
ADD CONSTRAINT check_qoh_validity
CHECK(quantityOnHand >=0);
INSERT INTO stocks VALUES (3,2,-1.00, '2026-10-01', NULL, 6,'2026-01-15');

ALTER TABLE consumes
ADD CONSTRAINT check_qu_validity
CHECK(quantityUsed >0);
INSERT INTO consumes VALUES (4,1,2,0.00);

-- 3
ALTER TABLE reservation
ADD CONSTRAINT check_reservation_validity
CHECK(plannedEnd > plannedStart);
INSERT INTO reservation VALUES (7,'2026-08-01 09:00:00', '2026-08-10 08:00:00', '2025-08-12 18:00:00', 'Prototype print', 'Completed', 6, 'P1', NULL);

ALTER TABLE maintenance
ADD CONSTRAINT check_maintenance_validity
CHECK(endTS >startTS);
INSERT INTO maintenance VALUES ('U1','2026-04-12 09:00:00','2025-04-12 12:00:00', 'Preventive', 'Lens cleaning', 150.00, 'Resolved', 7);

-- Answer to the question
/* A CHECK constraint cannot express RLMS business rules that require inspecting multiple rows in the same table or data from other tables.
Because it is evaluated on a single row of a single table at a time. it has no visibility into other rows or tables. Enforcing those rules requires triggers
*/









